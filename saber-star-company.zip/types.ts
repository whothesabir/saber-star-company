export enum Page {
  Home = 'Home',
  About = 'About',
  Products = 'Products',
  WhyChooseUs = 'Why Choose Us',
}
